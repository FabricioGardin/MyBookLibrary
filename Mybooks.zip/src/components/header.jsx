const Header = () => {
    return (
        <div className="header">
            <h1>My Book Library</h1>    
        </ div>
      );
}
 
export default Header;