const Footer = () => {
    return (   
        <div className="footer">
            <p>Copyright &copy; Fabricio Gardin {new Date().getFullYear()}</p>
        </div>
     );
}
 
export default Footer;